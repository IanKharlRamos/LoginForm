﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeChum_
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> userCredentials = new Dictionary<string, string>()
        {
            {"admin", "admin12345" },
            {"user1", "password123" },
            {"student1", "PF101@2024" }
        };
        public Form1()
        {
            InitializeComponent();

            // Set PasswordChar for passwordTextBox
            passwordTextBox.PasswordChar = 'X';

            // Set text for labels
            label1.Text = "Username:";
            label2.Text = "Password:";
            label3.Text = ""; // Initially empty
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            // Check if the entered username exists in the dictionary and if the corresponding password matches
            if (userCredentials.ContainsKey(username) && userCredentials[username] == password)
            {
                label3.Text = "Login Successful";
            }
            else
            {
                label3.Text = "Invalid username or password.";
            }
        }

    }
}
